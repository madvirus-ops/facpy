"""
facpy: Field-Aligned Current Python toolkit.
"""

__version__ = "0.1.1"
